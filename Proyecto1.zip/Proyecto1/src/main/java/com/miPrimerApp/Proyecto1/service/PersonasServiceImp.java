package com.miPrimerApp.Proyecto1.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.miPrimerApp.Proyecto1.dto.request.EdadDto;
import com.miPrimerApp.Proyecto1.dto.request.PersonaSaveDto;
import com.miPrimerApp.Proyecto1.dto.response.PersonaResponseDto;
import com.miPrimerApp.Proyecto1.dto.response.PersonasPorEdadDto;
import com.miPrimerApp.Proyecto1.dto.response.ResponseDto;
import com.miPrimerApp.Proyecto1.entity.Persona;
import com.miPrimerApp.Proyecto1.repository.IPersonasRepository;
import com.miPrimerApp.Proyecto1.repository.PersonasRepositoryImp;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonasServiceImp implements IPersonasService{
   private IPersonasRepository repository;
   public PersonasServiceImp(PersonasRepositoryImp repository){this.repository = repository;
   }

    @Override
    public ResponseDto guardarPersona(PersonaSaveDto persona) {
        ObjectMapper mapper= new ObjectMapper();
        Persona personaEntity= mapper.convertValue(persona, Persona.class);
        Persona respuesataRepo= repository.save(personaEntity);
        if(respuesataRepo == null){
            return new ResponseDto("No se logro guardar");  }
        return new ResponseDto("La persona"+ respuesataRepo.getNombre()+ "se guardo correctamente");

    }



    @Override
    public List<PersonaResponseDto> buscarTodos() {
       ObjectMapper mapper= new ObjectMapper();
        return repository.findAll().stream()
                .map(persona -> new PersonaResponseDto(persona.getNombre(),persona.getApellido())).toList();
    }

    @Override
    public List<PersonasPorEdadDto> buscarPorEdad(EdadDto edad) {

return repository.findByAge(edad).stream()
        .map(persona -> new PersonasPorEdadDto(persona.getNombre(), persona.getApellido(), persona.getEdad())).toList();    }
}

