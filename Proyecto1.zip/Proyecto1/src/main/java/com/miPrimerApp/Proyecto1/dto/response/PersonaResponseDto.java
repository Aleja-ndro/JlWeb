package com.miPrimerApp.Proyecto1.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PersonaResponseDto {
    private String nombre;
    private String apellido;
}
