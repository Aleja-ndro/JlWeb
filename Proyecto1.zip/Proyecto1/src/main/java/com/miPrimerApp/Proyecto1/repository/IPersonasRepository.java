package com.miPrimerApp.Proyecto1.repository;

import com.miPrimerApp.Proyecto1.dto.request.EdadDto;
import com.miPrimerApp.Proyecto1.entity.Persona;

import java.util.List;

public interface IPersonasRepository  {
    Persona save(Persona persona);
    List<Persona> findAll();
    List<Persona> findByAge(EdadDto edad);
}
