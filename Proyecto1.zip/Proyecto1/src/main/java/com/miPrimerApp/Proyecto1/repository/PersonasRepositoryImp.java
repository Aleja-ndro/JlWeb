package com.miPrimerApp.Proyecto1.repository;

import com.miPrimerApp.Proyecto1.dto.request.EdadDto;
import com.miPrimerApp.Proyecto1.dto.response.PersonaResponseDto;
import com.miPrimerApp.Proyecto1.entity.Persona;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class PersonasRepositoryImp implements IPersonasRepository {
    private final List<Persona>dataBase = new ArrayList<>();
    @Override
    public Persona save(Persona persona){
        persona.setId(dataBase.size()+1);
        dataBase.add(persona);
        return persona;
    }

    @Override
    public List<Persona> findAll() {
        return dataBase;
    }

    @Override
    public List<Persona> findByAge(EdadDto edad) {
        return dataBase.stream().filter(persona -> persona.getEdad()>=edad).toList() ;
    }
}
