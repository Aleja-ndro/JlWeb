package com.miPrimerApp.Proyecto1.controller;


import com.miPrimerApp.Proyecto1.dto.request.PersonaSaveDto;
import com.miPrimerApp.Proyecto1.dto.request.EdadDto;
import com.miPrimerApp.Proyecto1.dto.response.ResponseDto;
import com.miPrimerApp.Proyecto1.service.IPersonasService;
import com.miPrimerApp.Proyecto1.service.PersonasServiceImp;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class PersonasController {

  private IPersonasService service;
  public PersonasController(PersonasServiceImp service){
      this.service =service;

  }


@PostMapping("/guardar")
    public ResponseEntity<?> agregarPersona(@RequestBody PersonaSaveDto persona){
    ResponseDto respuesta= service.guardarPersona(persona);
    return new ResponseEntity<>(respuesta, HttpStatus.OK);


    }
   @
    GetMapping("/buscarTodos")
    public ResponseEntity<?>buscarTodos(){
      return new ResponseEntity<>(service.buscarTodos(),HttpStatus.OK);
   }
    @GetMapping("/buscar/{edad}")
    public ResponseEntity<?>obtenerPorEdad(@PathVariable int edad){
      return new ResponseEntity<>(service.buscarPorEdad(new EdadDto(edad)),HttpStatus.OK);
    }

}

