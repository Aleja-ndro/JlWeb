package com.miPrimerApp.Proyecto1.service;

import com.miPrimerApp.Proyecto1.dto.request.EdadDto;
import com.miPrimerApp.Proyecto1.dto.request.PersonaSaveDto;
import com.miPrimerApp.Proyecto1.dto.response.PersonaResponseDto;
import com.miPrimerApp.Proyecto1.dto.response.PersonasPorEdadDto;
import com.miPrimerApp.Proyecto1.dto.response.ResponseDto;

import java.util.List;

public interface IPersonasService {
    ResponseDto guardarPersona(PersonaSaveDto persona);


    List<PersonaResponseDto> buscarTodos();
    List<PersonasPorEdadDto> buscarPorEdad(EdadDto edad);

}
